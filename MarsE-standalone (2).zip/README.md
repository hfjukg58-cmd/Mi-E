# Mars E

Mars E is a mobile-first English-learning application for Arabic speakers. This export is standalone: it runs with Expo/React Native, an Express/tRPC API, MySQL, and optional Grok AI. It does not require Manus or WebDev.

## Included

- Expo Router mobile frontend with RTL Arabic UI.
- Express/tRPC backend and Drizzle/MySQL schema plus migrations.
- Offline-friendly profile, XP, streak, vocabulary, lessons, stories, practice and reports.
- Optional Grok integration through the server-only `GROK_API_KEY`.
- EAS configuration for Android APK builds.
- Dockerfile and Docker Compose for the API and MySQL.
- No API keys, tokens, `.env`, `.git`, `node_modules`, or build artifacts are included.

## Requirements

- Node.js 22+
- pnpm 9+
- MySQL 8+ for durable server data
- Expo Go for device development, or an EAS account for cloud APK builds

## Local setup

```bash
cp .env.example .env
# Edit .env and set a long JWT_SECRET, DATABASE_URL, and optionally GROK_API_KEY
pnpm install --frozen-lockfile
pnpm db:push
pnpm dev
```

Metro/Web runs on `http://localhost:8081`; the API runs on `http://localhost:3000`. For a phone on the same network, set `EXPO_PUBLIC_API_BASE_URL` to the computer's reachable API URL.

## Checks

```bash
pnpm check
pnpm lint
pnpm test
pnpm build
```

## Android APK

The repository includes `eas.json` with a preview APK profile:

```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

The command returns an Expo build URL after the cloud build completes. Do not put an Expo token or API key in source code; use `eas login` or `EXPO_TOKEN` in the shell environment.

## Docker

```bash
cp .env.example .env
docker compose up --build
```

The API is available on port `3000`. Docker Compose starts MySQL with a persistent named volume. The Expo mobile bundle remains a client and can be built with EAS or run with `pnpm dev:metro` from the host.

## Environment variables

Server-only: `DATABASE_URL`, `JWT_SECRET`, `GROK_API_KEY`, `OAUTH_SERVER_URL`, `OWNER_OPEN_ID`, `PORT`.

Client-safe: `EXPO_PUBLIC_API_BASE_URL`, `EXPO_PUBLIC_OAUTH_PORTAL_URL`, `EXPO_PUBLIC_OAUTH_SERVER_URL`, `EXPO_PUBLIC_APP_ID`.

OAuth is optional in this standalone export. Learning content, local progress, exercises, stories, and AI fallback work without an account provider. Configure an external OAuth provider before enabling account login in production.

## Architecture

- `app/`: Expo Router screens.
- `components/`: reusable Mars UI.
- `lib/`: local state, API client, theme and standalone runtime.
- `shared/`: shared schemas and seed content.
- `server/`: Express/tRPC routes, Grok service, auth context and database repositories.
- `drizzle/`: MySQL schema and migrations.
- `eas.json`: Android APK/AAB build profiles.
- `Dockerfile`, `docker-compose.yml`: backend deployment.
