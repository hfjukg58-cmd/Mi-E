import { Ionicons } from "@expo/vector-icons";
import { useEffect, useRef, useState } from "react";
import { Alert, Platform, Pressable, Text, TextInput, View } from "react-native";
import { Card, MarsAvatar, SecondaryButton } from "@/components/mars-ui";
import { MarsScreen } from "@/components/mars-screen";
import { getApiBaseUrl } from "@/constants/oauth";
import { useColors } from "@/hooks/use-colors";
import { useMars } from "@/lib/mars-store";

type AiResponse = { reply: string; correction: { hasError: boolean; original: string; corrected: string; explanation_ar: string }; newWords: { word: string; meaning_ar: string }[]; grammarPoint: string; difficulty: string; encouragement: string };
type Message = { id: string; role: "mars" | "user"; text: string; response?: AiResponse };

const fallback = (input: string): AiResponse => {
  const hasPastError = /yesterday|last week|ago/i.test(input) && /\bgo\b/i.test(input);
  return { reply: hasPastError ? "Tell me what you did yesterday using the past tense." : "That is a great start! Tell me one more detail in English.", correction: hasPastError ? { hasError: true, original: input, corrected: input.replace(/\bgo\b/i, "went"), explanation_ar: "نستخدم الماضي مع yesterday، والفعل go يصبح went." } : { hasError: false, original: input, corrected: input, explanation_ar: "جملتك واضحة. استمر في استخدام جمل قصيرة وواضحة." }, newWords: [{ word: "detail", meaning_ar: "تفصيل" }], grammarPoint: hasPastError ? "Past Simple" : "Conversation confidence", difficulty: "beginner", encouragement: hasPastError ? "Good effort — mistakes help us learn!" : "Great effort!" };
};

export default function ConversationScreen() {
  const colors = useColors();
  const { profile, marsState, setMarsState, recordConversation, addVocabulary } = useMars();
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([{ id: "welcome", role: "mars", text: "Hi! I’m Mars. Tell me about your day in English." }]);
  const [loading, setLoading] = useState(false);
  const recognitionRef = useRef<any>(null);
  useEffect(() => () => recognitionRef.current?.stop?.(), []);
  const speak = (text: string) => {
    if (Platform.OS === "web" && typeof window !== "undefined" && "speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text); utterance.lang = "en-US"; utterance.rate = 0.95; window.speechSynthesis.cancel(); window.speechSynthesis.speak(utterance); setMarsState("speaking"); setTimeout(() => setMarsState("idle"), 900);
    } else Alert.alert("الصوت", "تشغيل الصوت متاح في Web Preview عبر Web Speech. جرّب فتح التطبيق من المتصفح.");
  };
  const listen = () => {
    if (Platform.OS !== "web") { Alert.alert("الميكروفون", "تعذر الوصول إلى الميكروفون في هذه الجلسة. جرّب Expo Go مع صلاحية الميكروفون."); setMarsState("error"); return; }
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) { Alert.alert("الميكروفون", "تعذر الوصول إلى الميكروفون. استخدم الكتابة أو متصفحًا يدعم Speech Recognition."); setMarsState("error"); return; }
    const recognition = new SpeechRecognition(); recognition.lang = "en-US"; recognition.interimResults = false; recognition.onstart = () => setMarsState("listening"); recognition.onresult = (event: any) => setInput(event.results[0][0].transcript); recognition.onerror = () => { setMarsState("error"); Alert.alert("الميكروفون", "تعذر الوصول إلى الميكروفون."); }; recognition.onend = () => setMarsState("idle"); recognitionRef.current = recognition; recognition.start();
  };
  const send = async () => {
    const text = input.trim(); if (!text || loading) return; setInput(""); setLoading(true); setMarsState("thinking"); setMessages((current) => [...current, { id: `${Date.now()}-u`, role: "user", text }]); let response = fallback(text);
    try { const result = await fetch(`${getApiBaseUrl()}/api/ai/chat`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: text, level: profile?.level ?? "Beginner" }) }); if (result.ok) { const body = await result.json(); if (body?.reply && body?.correction) response = body as AiResponse; } } catch { /* keep offline fallback */ }
    setMessages((current) => [...current, { id: `${Date.now()}-m`, role: "mars", text: response.reply, response }]); response.newWords.forEach((word) => addVocabulary({ word: word.word, meaning: word.meaning_ar, example: response.reply, level: profile?.level ?? "Beginner", mastery: 0 })); recordConversation(); setMarsState(response.correction.hasError ? "correction" : "happy"); setLoading(false);
  };
  return <MarsScreen title="Conversation" subtitle="English first · شرح عربي عند الحاجة" back>
    <View style={{ alignItems: "center", gap: 8 }}><MarsAvatar state={marsState} size={88} /><Text style={{ color: colors.muted, fontSize: 12 }}>Mars · AI English teacher</Text></View>
    <Card style={{ gap: 14 }}>
      {messages.map((message) => <View key={message.id} style={{ alignItems: message.role === "user" ? "flex-start" : "flex-end" }}><View style={{ maxWidth: "88%", borderRadius: 17, padding: 13, backgroundColor: message.role === "user" ? colors.primarySoft : colors.background }}>
        <Text style={{ color: colors.foreground, lineHeight: 22, textAlign: message.role === "user" ? "left" : "right" }}>{message.text}</Text>
        {message.role === "mars" && message.response ? <><Pressable onPress={() => speak(message.text)} style={{ flexDirection: "row", alignItems: "center", gap: 5, marginTop: 8 }}><Ionicons name="volume-high-outline" color={colors.primary} size={16} /><Text style={{ color: colors.primary, fontSize: 12, fontWeight: "700" }}>استمع</Text></Pressable>{message.response.correction.hasError ? <View style={{ marginTop: 10, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 10, gap: 5 }}><Text style={{ color: colors.error, fontWeight: "800", textAlign: "right" }}>تصحيح لطيف</Text><Text style={{ color: colors.muted, fontSize: 12, textAlign: "right" }}>إجابتك: {message.response.correction.original}</Text><Text style={{ color: colors.success, fontSize: 12, textAlign: "right" }}>الصحيح: {message.response.correction.corrected}</Text><Text style={{ color: colors.foreground, fontSize: 12, lineHeight: 18, textAlign: "right" }}>لماذا؟ {message.response.correction.explanation_ar}</Text></View> : <Text style={{ color: colors.success, fontSize: 12, fontWeight: "700", marginTop: 7, textAlign: "right" }}>✓ ممتاز! إجابة صحيحة.</Text>}</> : null}
      </View></View>)}
    </Card>
    {loading ? <Text style={{ color: colors.muted, textAlign: "center" }}>Mars يفكر…</Text> : null}
    <View style={{ flexDirection: "row", gap: 8, alignItems: "flex-end" }}><Pressable accessibilityLabel="تحدث" onPress={listen} style={{ width: 50, height: 52, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: marsState === "listening" ? colors.error : colors.primarySoft }}><Ionicons name={marsState === "listening" ? "radio" : "mic-outline"} size={23} color={marsState === "listening" ? colors.error : colors.primary} /></Pressable><TextInput accessibilityLabel="اكتب بالإنجليزية" value={input} onChangeText={setInput} placeholder="اكتب بدل التحدث…" placeholderTextColor={colors.muted} multiline style={{ flex: 1, minHeight: 52, maxHeight: 100, borderRadius: 16, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, color: colors.foreground, paddingHorizontal: 14, paddingTop: 14, textAlign: "left" }} /><Pressable accessibilityLabel="إرسال" onPress={send} style={{ width: 50, height: 52, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: colors.primary }}><Ionicons name="send" size={20} color="#fff" /></Pressable></View>
    <SecondaryButton label="اشرح لي أكثر" icon="help-circle-outline" onPress={() => setInput("Can you explain the correction more simply?")} />
  </MarsScreen>;
}

declare global { interface Window { SpeechRecognition?: any; webkitSpeechRecognition?: any; } }
