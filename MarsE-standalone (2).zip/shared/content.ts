import type { Level } from "@/lib/mars-store";

export type GrammarLesson = { id: string; level: Level; title: string; titleAr: string; explanation: string; examples: { en: string; ar: string }[]; progress: number };
export type Exercise = { id: string; type: "multiple-choice" | "fill" | "arrange"; question: string; promptAr: string; options?: string[]; answer: string; explanation: string };
export type Story = { id: string; level: Level; title: string; titleAr: string; text: string; translation: string; words: { word: string; meaning: string }[]; question: string; answer: string };

export const grammarLessons: GrammarLesson[] = [
  { id: "verb-to-be", level: "Beginner", title: "Verb to be", titleAr: "فعل يكون", explanation: "نستخدم am وis وare للحديث عن الهوية والصفات والحالة.", examples: [{ en: "I am ready.", ar: "أنا مستعد." }, { en: "She is a teacher.", ar: "هي معلمة." }], progress: 68 },
  { id: "present-simple", level: "Beginner", title: "Present Simple", titleAr: "المضارع البسيط", explanation: "نستخدمه للعادات والحقائق. أضف s مع he وshe وit.", examples: [{ en: "I study every day.", ar: "أدرس كل يوم." }, { en: "He works in Riyadh.", ar: "هو يعمل في الرياض." }], progress: 42 },
  { id: "past-simple", level: "Beginner", title: "Past Simple", titleAr: "الماضي البسيط", explanation: "نستخدمه لحدث انتهى في الماضي. انتبه للأفعال الشاذة مثل go → went.", examples: [{ en: "I went yesterday.", ar: "ذهبت أمس." }, { en: "They visited London.", ar: "زاروا لندن." }], progress: 18 },
  { id: "present-perfect", level: "Intermediate", title: "Present Perfect", titleAr: "المضارع التام", explanation: "have/has + past participle لخبرة أو حدث مرتبط بالحاضر.", examples: [{ en: "I have finished my work.", ar: "أنهيت عملي." }], progress: 22 },
  { id: "conditionals", level: "Intermediate", title: "Conditionals", titleAr: "الجمل الشرطية", explanation: "If + present, will + verb للتوقعات والنتائج المحتملة.", examples: [{ en: "If I practice, I will improve.", ar: "إذا تدربت فسأتحسن." }], progress: 8 },
  { id: "reported-speech", level: "Advanced", title: "Reported Speech", titleAr: "الكلام المنقول", explanation: "ننقل كلام شخص آخر مع تغيير الضمائر والزمن عند الحاجة.", examples: [{ en: "She said she was busy.", ar: "قالت إنها مشغولة." }], progress: 0 },
];

export const exercises: Exercise[] = [
  { id: "ex-1", type: "multiple-choice", question: "I ___ to work every day.", promptAr: "اختر الإجابة الصحيحة للمضارع البسيط", options: ["go", "went", "going"], answer: "go", explanation: "نستخدم go مع I في العادات اليومية." },
  { id: "ex-2", type: "fill", question: "Yesterday, I ___ a new word.", promptAr: "أكمل الجملة بالماضي", answer: "learned", explanation: "Yesterday يدل على الماضي، وlearn تصبح learned." },
  { id: "ex-3", type: "arrange", question: "Arrange: / opportunity / is / This / great / a", promptAr: "رتب الكلمات", answer: "This is a great opportunity", explanation: "ترتيب الجملة الإنجليزية: فاعل ثم فعل ثم مفعول/وصف." },
  { id: "ex-4", type: "multiple-choice", question: "She ___ confident today.", promptAr: "اختر فعل to be", options: ["am", "is", "are"], answer: "is", explanation: "نستخدم is مع She." },
];

export const stories: Story[] = [
  { id: "story-coffee", level: "Beginner", title: "A New Morning", titleAr: "صباح جديد", text: "Maya wakes up early. She makes coffee and practices three English sentences before work.", translation: "تستيقظ مايا مبكرًا. تصنع القهوة وتتدرب على ثلاث جمل إنجليزية قبل العمل.", words: [{ word: "early", meaning: "مبكرًا" }, { word: "practice", meaning: "يتدرب" }], question: "What does Maya make?", answer: "coffee" },
  { id: "story-interview", level: "Intermediate", title: "The Opportunity", titleAr: "الفرصة", text: "Omar prepares for an interview by describing his strengths clearly. He stays calm and asks one thoughtful question.", translation: "يستعد عمر لمقابلة بوصف نقاط قوته بوضوح. يبقى هادئًا ويسأل سؤالًا جيدًا.", words: [{ word: "strengths", meaning: "نقاط القوة" }, { word: "thoughtful", meaning: "مدروس / عميق" }], question: "How does Omar stay?", answer: "calm" },
  { id: "story-travel", level: "Advanced", title: "Across the City", titleAr: "عبر المدينة", text: "Although the train was delayed, Lina used the extra time to review a presentation and arrived prepared.", translation: "رغم تأخر القطار، استغلت لينا الوقت الإضافي لمراجعة عرض ووصلت مستعدة.", words: [{ word: "although", meaning: "رغم أن" }, { word: "delayed", meaning: "متأخر" }], question: "What did Lina review?", answer: "a presentation" },
];

export const dailySteps = [
  { id: "vocabulary", label: "Vocabulary", labelAr: "كلمات جديدة", minutes: 3, icon: "book-outline" },
  { id: "grammar", label: "Grammar", labelAr: "قاعدة اليوم", minutes: 4, icon: "school-outline" },
  { id: "exercise", label: "Exercise", labelAr: "تمرين قصير", minutes: 3, icon: "checkmark-circle-outline" },
  { id: "conversation", label: "Conversation", labelAr: "تحدث مع Mars", minutes: 3, icon: "chatbubbles-outline" },
  { id: "review", label: "Review", labelAr: "مراجعة سريعة", minutes: 2, icon: "sparkles-outline" },
];
