import { z } from "zod";

export const aiResponseSchema = z.object({
  reply: z.string().min(1).max(2000),
  correction: z.object({ hasError: z.boolean(), original: z.string(), corrected: z.string(), explanation_ar: z.string() }),
  newWords: z.array(z.object({ word: z.string().min(1), meaning_ar: z.string().min(1) })).max(8),
  grammarPoint: z.string().max(120),
  difficulty: z.enum(["beginner", "intermediate", "advanced"]),
  encouragement: z.string().max(240),
});
export type AiResponse = z.infer<typeof aiResponseSchema>;

export function parseAiResponse(value: unknown): AiResponse | null {
  const parsed = aiResponseSchema.safeParse(value);
  return parsed.success ? parsed.data : null;
}
