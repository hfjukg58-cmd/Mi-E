import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import { Animated, Pressable, StyleSheet, Text, View, type PressableProps, type StyleProp, type ViewStyle } from "react-native";
import { useColors } from "@/hooks/use-colors";
import type { MarsState } from "@/lib/mars-store";

export function Card({ children, style, onPress }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; onPress?: PressableProps["onPress"] }) {
  const colors = useColors();
  return <Pressable onPress={onPress} style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }, style]}>{children}</Pressable>;
}

export function PrimaryButton({ label, icon, onPress, disabled }: { label: string; icon?: keyof typeof Ionicons.glyphMap; onPress?: () => void; disabled?: boolean }) {
  const colors = useColors();
  return <Pressable accessibilityRole="button" accessibilityLabel={label} disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: disabled ? 0.5 : pressed ? 0.82 : 1 }]}><Text style={styles.primaryButtonText}>{label}</Text>{icon ? <Ionicons name={icon} size={19} color="#fff" /> : null}</Pressable>;
}

export function SecondaryButton({ label, icon, onPress }: { label: string; icon?: keyof typeof Ionicons.glyphMap; onPress?: () => void }) {
  const colors = useColors();
  return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({ pressed }) => [styles.secondaryButton, { borderColor: colors.border, backgroundColor: colors.surface, opacity: pressed ? 0.75 : 1 }]}>{icon ? <Ionicons name={icon} size={18} color={colors.primary} /> : null}<Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>{label}</Text></Pressable>;
}

export function ProgressBar({ value, color }: { value: number; color?: string }) {
  const colors = useColors();
  return <View style={[styles.progressTrack, { backgroundColor: colors.border }]}><View style={[styles.progressFill, { width: `${Math.min(100, Math.max(0, value))}%`, backgroundColor: color ?? colors.primary }]} /></View>;
}

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const colors = useColors();
  return <View style={styles.sectionTitle}><Text style={[styles.sectionTitleText, { color: colors.foreground }]}>{title}</Text>{action ? <Pressable onPress={onAction}><Text style={[styles.sectionAction, { color: colors.primary }]}>{action}</Text></Pressable> : null}</View>;
}

export function MarsAvatar({ state = "idle", size = 92 }: { state?: MarsState; size?: number }) {
  const colors = useColors();
  const [pulse] = useState(() => new Animated.Value(0));
  useEffect(() => {
    const active = state === "listening" || state === "thinking" || state === "speaking";
    if (!active) { pulse.stopAnimation(); pulse.setValue(0); return; }
    const loop = Animated.loop(Animated.sequence([Animated.timing(pulse, { toValue: 1, duration: 850, useNativeDriver: true }), Animated.timing(pulse, { toValue: 0, duration: 850, useNativeDriver: true })]));
    loop.start();
    return () => loop.stop();
  }, [pulse, state]);
  const scale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.08] });
  const stateLabel: Record<MarsState, string> = { idle: "جاهز", welcome: "مرحبًا", listening: "أستمع", thinking: "أفكر", speaking: "أتحدث", correct: "رائع!", correction: "لنجربها", happy: "ممتاز", error: "نحتاج اتصالًا", encouraging: "أنت تستطيع" };
  const emoji: Record<MarsState, string> = { idle: "✦", welcome: "✦", listening: "◉", thinking: "…", speaking: "◌", correct: "✓", correction: "↗", happy: "★", error: "!", encouraging: "↗" };
  return <View style={{ alignItems: "center", gap: 7 }}><Animated.View style={[styles.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: colors.primarySoft, borderColor: colors.primary, transform: [{ scale }] }]}><Text style={[styles.avatarMark, { color: colors.primary, fontSize: size * 0.42 }]}>{emoji[state]}</Text><View style={[styles.avatarDot, { backgroundColor: state === "error" ? colors.error : colors.success }]} /></Animated.View><Text style={[styles.avatarLabel, { color: colors.muted }]}>{stateLabel[state]}</Text></View>;
}

export function EmptyState({ title, body, icon = "sparkles-outline" }: { title: string; body: string; icon?: keyof typeof Ionicons.glyphMap }) {
  const colors = useColors();
  return <View style={[styles.empty, { borderColor: colors.border }]}><Ionicons name={icon} size={28} color={colors.primary} /><Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text><Text style={[styles.emptyBody, { color: colors.muted }]}>{body}</Text></View>;
}

export const styles = StyleSheet.create({
  card: { borderRadius: 24, borderWidth: 1, padding: 18, gap: 12, shadowColor: "#0b3b4a", shadowOpacity: 0.06, shadowRadius: 16, shadowOffset: { width: 0, height: 6 }, elevation: 2 },
  primaryButton: { minHeight: 52, borderRadius: 17, paddingHorizontal: 20, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9 },
  primaryButtonText: { color: "#fff", fontSize: 16, fontWeight: "800" },
  secondaryButton: { minHeight: 48, borderRadius: 15, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, borderWidth: 1 },
  secondaryButtonText: { fontSize: 14, fontWeight: "700" },
  progressTrack: { height: 8, borderRadius: 8, overflow: "hidden" },
  progressFill: { height: "100%", borderRadius: 8 },
  sectionTitle: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 4 },
  sectionTitleText: { fontSize: 20, fontWeight: "800" },
  sectionAction: { fontSize: 13, fontWeight: "700" },
  avatar: { alignItems: "center", justifyContent: "center", borderWidth: 2, shadowColor: "#65c7d9", shadowOpacity: 0.25, shadowRadius: 18, shadowOffset: { width: 0, height: 6 }, elevation: 4 },
  avatarMark: { fontWeight: "900" },
  avatarDot: { position: "absolute", right: 4, bottom: 5, width: 12, height: 12, borderRadius: 6, borderWidth: 2, borderColor: "#fff" },
  avatarLabel: { fontSize: 12, fontWeight: "700" },
  empty: { borderWidth: 1, borderRadius: 20, padding: 24, alignItems: "center", gap: 10 },
  emptyTitle: { fontSize: 18, fontWeight: "800" },
  emptyBody: { fontSize: 14, textAlign: "center", lineHeight: 22 },
});
