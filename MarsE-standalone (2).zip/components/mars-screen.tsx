import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";

export function MarsScreen({ title, subtitle, children, back = false }: { title: string; subtitle?: string; children: React.ReactNode; back?: boolean }) {
  const colors = useColors();
  const router = useRouter();
  return <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]} edges={["top", "left", "right"]}><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}><View style={styles.header}>{back ? <Ionicons accessibilityLabel="رجوع" name="arrow-forward" size={24} color={colors.foreground} onPress={() => router.back()} /> : <View style={{ width: 24 }} />}<View style={{ flex: 1 }}><Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>{subtitle ? <Text style={[styles.subtitle, { color: colors.muted }]}>{subtitle}</Text> : null}</View><View style={[styles.miniMark, { backgroundColor: colors.primarySoft }]}><Text style={{ color: colors.primary, fontWeight: "900" }}>M</Text></View></View>{children}</ScrollView></SafeAreaView>;
}

export function StatPill({ icon, value, label, color }: { icon: keyof typeof Ionicons.glyphMap; value: string; label: string; color: string }) {
  const colors = useColors();
  return <View style={[styles.stat, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name={icon} size={18} color={color} /><View><Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text><Text style={[styles.statLabel, { color: colors.muted }]}>{label}</Text></View></View>;
}

export const screenStyles = StyleSheet.create({ row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, two: { flexDirection: "row", gap: 10 }, muted: { fontSize: 13, lineHeight: 20 }, body: { fontSize: 15, lineHeight: 24 }, label: { fontSize: 12, fontWeight: "700", letterSpacing: 0.4 }, h2: { fontSize: 20, fontWeight: "800" }, h3: { fontSize: 16, fontWeight: "800" } });
const styles = StyleSheet.create({ safe: { flex: 1 }, content: { padding: 18, gap: 18, paddingBottom: 40 }, header: { flexDirection: "row", alignItems: "center", gap: 12, minHeight: 58 }, title: { fontSize: 28, fontWeight: "900", textAlign: "right" }, subtitle: { fontSize: 13, marginTop: 3, textAlign: "right" }, miniMark: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" }, stat: { flex: 1, borderWidth: 1, borderRadius: 18, padding: 12, flexDirection: "row", alignItems: "center", gap: 8 }, statValue: { fontWeight: "900", fontSize: 17 }, statLabel: { fontSize: 11, marginTop: 2 } });
