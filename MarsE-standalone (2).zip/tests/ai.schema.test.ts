import { describe, expect, it } from "vitest";
import { aiResponseSchema, parseAiResponse } from "../shared/ai-schema";
import { askGrok } from "../server/services/grok";

describe("Mars AI response validation", () => {
  it("accepts the documented JSON response shape", () => {
    const response = { reply: "Nice work!", correction: { hasError: false, original: "I study", corrected: "I study", explanation_ar: "جملة صحيحة." }, newWords: [{ word: "practice", meaning_ar: "يتدرب" }], grammarPoint: "Present Simple", difficulty: "beginner", encouragement: "Keep going!" };
    expect(aiResponseSchema.parse(response).reply).toBe("Nice work!");
  });
  it("rejects malformed AI output instead of crashing", () => {
    expect(parseAiResponse({ reply: "only text" })).toBeNull();
  });
  it("returns a safe teacher response when the key is not configured", async () => {
    const previous = process.env.GROK_API_KEY;
    delete process.env.GROK_API_KEY;
    const result = await askGrok("I go yesterday", "Beginner");
    expect(result.configured).toBe(false);
    expect(result.response.correction.corrected).toContain("went");
    if (previous) process.env.GROK_API_KEY = previous;
  });
});
