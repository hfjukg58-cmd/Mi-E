import "./scripts/load-env.js";
import type { ExpoConfig } from "expo/config";

const config: ExpoConfig = {
  name: "Mars E",
  slug: "mars-e",
  version: "1.0.0",
  orientation: "portrait",
  scheme: "marse",
  icon: "./assets/images/icon.png",
  userInterfaceStyle: "automatic",
  extra: {
    apiBaseUrl: process.env.EXPO_PUBLIC_API_BASE_URL ?? "",
    oauthPortalUrl: process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL ?? "",
    oauthServerUrl: process.env.EXPO_PUBLIC_OAUTH_SERVER_URL ?? "",
    appId: process.env.EXPO_PUBLIC_APP_ID ?? "com.marse.app",
  },
  ios: { supportsTablet: true, bundleIdentifier: "com.marse.app", infoPlist: { ITSAppUsesNonExemptEncryption: false } },
  android: {
    package: "com.marse.app",
    adaptiveIcon: { backgroundColor: "#E6F4FE", foregroundImage: "./assets/images/android-icon-foreground.png", backgroundImage: "./assets/images/android-icon-background.png", monochromeImage: "./assets/images/android-icon-monochrome.png" },
    permissions: ["POST_NOTIFICATIONS"],
  },
  web: { bundler: "metro", output: "static", favicon: "./assets/images/favicon.png" },
  plugins: [
    "expo-asset",
    "expo-router",
    ["expo-audio", { microphonePermission: "Allow Mars E to access your microphone." }],
    ["expo-video", { supportsBackgroundPlayback: true, supportsPictureInPicture: true }],
    ["expo-splash-screen", { image: "./assets/images/splash-icon.png", imageWidth: 200, resizeMode: "contain", backgroundColor: "#ffffff" }],
    ["expo-build-properties", { android: { buildArchs: ["armeabi-v7a", "arm64-v8a"], minSdkVersion: 24 } }],
  ],
  experiments: { typedRoutes: true, reactCompiler: true },
};

export default config;
