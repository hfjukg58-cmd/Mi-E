import { z } from "zod";
import { getSessionCookieName, getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { deleteUserData, getProgressSnapshot, recordLearningEvent, type LearningEvent } from "./db";
import { exercises, grammarLessons, stories } from "../shared/content";

const eventSchema = z.object({ event: z.enum(["conversation", "vocabulary", "exercise", "exerciseCorrect", "pronunciation", "interview"]), amount: z.number().int().min(1).max(100).default(1) });

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(getSessionCookieName(ctx.req), { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  learning: router({
    content: publicProcedure.query(() => ({ grammarLessons, exercises, stories })),
    record: protectedProcedure.input(eventSchema).mutation(async ({ input, ctx }) => ({ ok: true, ...(await recordLearningEvent(ctx.user.id, input.event as LearningEvent, input.amount)) })),
  }),
  progress: router({
    snapshot: protectedProcedure.query(({ ctx }) => getProgressSnapshot(ctx.user.id)),
  }),
  privacy: router({
    deleteData: protectedProcedure.mutation(async ({ ctx }) => ({ ok: true, ...(await deleteUserData(ctx.user.id)) })),
  }),
});

export type AppRouter = typeof appRouter;
