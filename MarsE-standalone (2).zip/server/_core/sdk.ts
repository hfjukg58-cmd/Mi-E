import type { Request } from "express";
import type { User } from "../../drizzle/schema";

export const sdk = {
  async authenticateRequest(_req: Request): Promise<User | null> {
    // Standalone builds intentionally keep account authentication optional.
    // Add your own JWT/OAuth verifier here before enabling protected procedures.
    return null;
  },
};
