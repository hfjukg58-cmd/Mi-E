import type { RequestHandler } from "express";

function isLoopback(hostname: string) {
  const value = hostname.replace(/^\[|\]$/g, "").toLowerCase();
  return value === "localhost" || value === "127.0.0.1" || value === "::1" || value.endsWith(".localhost");
}

function configuredOrigins() {
  return new Set((process.env.CORS_ORIGINS ?? "").split(",").map((value) => value.trim()).filter(Boolean));
}

export function trustedExpoWebOrigins() { return configuredOrigins(); }

export function createCorsMiddleware(allowedOrigins = configuredOrigins()): RequestHandler {
  return (req, res, next) => {
    const origin = req.headers.origin;
    res.vary("Origin");
    if (!origin) return next();
    let hostname = "";
    try { hostname = new URL(origin).hostname; } catch { return res.status(403).json({ error: "origin_not_allowed" }); }
    if (!allowedOrigins.has(origin) && !(isLoopback(hostname) && isLoopback(req.hostname))) return res.status(403).json({ error: "origin_not_allowed" });
    res.header("Access-Control-Allow-Origin", origin);
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type, Accept, Authorization, X-Requested-With");
    res.header("Access-Control-Allow-Credentials", "true");
    if (req.method === "OPTIONS") return res.sendStatus(204);
    next();
  };
}
