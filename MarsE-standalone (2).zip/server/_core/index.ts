import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { createCorsMiddleware } from "./cors";
import { clearLegacySessionCookie } from "./cookies";
import { askGrok } from "../services/grok";

async function startServer() {
  const app = express();
  const server = createServer(app);
  const aiRate = new Map<string, { started: number; count: number }>();

  app.use(createCorsMiddleware());
  app.use(clearLegacySessionCookie());

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerOAuthRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  app.post("/api/ai/chat", async (req, res) => {
    const key = req.ip ?? req.socket.remoteAddress ?? "unknown";
    const now = Date.now();
    const bucket = aiRate.get(key);
    if (!bucket || now - bucket.started > 60_000) aiRate.set(key, { started: now, count: 1 });
    else if (bucket.count >= 30) return res.status(429).json({ error: "محاولات كثيرة. انتظر دقيقة ثم حاول مرة أخرى." });
    else bucket.count += 1;
    const message = typeof req.body?.message === "string" ? req.body.message.trim().slice(0, 2000) : "";
    const level = typeof req.body?.level === "string" ? req.body.level : "Beginner";
    if (!message) return res.status(400).json({ error: "Message is required" });
    try {
      const result = await askGrok(message, level);
      return res.json({ ...result.response, meta: { configured: result.configured } });
    } catch {
      return res.status(503).json({ error: "تعذر الاتصال بالمدرس الذكي. حاول مرة أخرى." });
    }
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const port = parseInt(process.env.PORT || "3000");
  server.listen(port, () => {
    console.log("[api] server listening");
  });
}

startServer().catch(() => {
  console.error("[api] server failed to start");
});
