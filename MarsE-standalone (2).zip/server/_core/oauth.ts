import type { Express } from "express";

export function registerOAuthRoutes(app: Express) {
  app.get("/api/oauth/callback", (_req, res) => res.status(501).json({ error: "OAuth is not configured for this standalone build." }));
  app.get("/api/oauth/mobile", (_req, res) => res.status(501).json({ error: "Configure an external OAuth provider before enabling account login." }));
}
