import { parse as parseCookieHeader } from "cookie";
import type { CookieOptions, Request, RequestHandler } from "express";

const COOKIE_NAME = "mars_e_session";
const LEGACY_COOKIE_NAME = "mars_e_legacy_session";

function isSecureRequest(req: Request) {
  if (req.protocol === "https") return true;
  const forwarded = req.headers["x-forwarded-proto"];
  return typeof forwarded === "string" && forwarded.split(",").some((value) => value.trim() === "https");
}

export function getSessionCookieOptions(req: Request): Pick<CookieOptions, "httpOnly" | "path" | "sameSite" | "secure"> {
  const secure = isSecureRequest(req);
  return { httpOnly: true, path: "/", sameSite: secure ? "none" : "lax", secure };
}
export function getSessionCookieName(_req: Request) { return COOKIE_NAME; }
export function getLegacySessionCookieOptions(req: Request): Pick<CookieOptions, "domain" | "httpOnly" | "path" | "sameSite" | "secure"> { const base = getSessionCookieOptions(req); return { ...base, domain: undefined }; }
export function clearLegacySessionCookie(): RequestHandler { return (_req, res, next) => { res.clearCookie(LEGACY_COOKIE_NAME); next(); }; }
export function currentSessionCookie(req: Request) { return req.headers.cookie ? parseCookieHeader(req.headers.cookie)[COOKIE_NAME] : undefined; }
