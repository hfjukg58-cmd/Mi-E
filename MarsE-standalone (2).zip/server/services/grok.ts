import { aiResponseSchema, type AiResponse } from "../../shared/ai-schema";

const fallback = (message: string, level: string): AiResponse => {
  const hasPastError = /yesterday|last week|ago/i.test(message) && /\bgo\b/i.test(message);
  return { reply: hasPastError ? "Tell me what you did yesterday using the past tense." : "That is a great start! Tell me one more detail in English.", correction: hasPastError ? { hasError: true, original: message, corrected: message.replace(/\bgo\b/i, "went"), explanation_ar: "نستخدم الماضي مع yesterday، والفعل go يصبح went." } : { hasError: false, original: message, corrected: message, explanation_ar: "جملتك واضحة. استمر في استخدام جمل قصيرة وواضحة." }, newWords: [{ word: "detail", meaning_ar: "تفصيل" }], grammarPoint: hasPastError ? "Past Simple" : "Conversation confidence", difficulty: level.toLowerCase() as AiResponse["difficulty"], encouragement: hasPastError ? "Good effort — mistakes help us learn!" : "Great effort!" };
};

const systemPrompt = "You are Mars, a patient English teacher for Arabic speakers. Speak English in reply, explain corrections in simple Arabic, adapt to the learner level, encourage gently, and return only valid JSON with reply, correction, newWords, grammarPoint, difficulty, encouragement.";

export async function askGrok(message: string, level: string): Promise<{ response: AiResponse; configured: boolean }> {
  const key = process.env.GROK_API_KEY;
  if (!key) return { response: fallback(message, level), configured: false };
  try {
    const result = await fetch("https://api.x.ai/v1/chat/completions", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` }, body: JSON.stringify({ model: "grok-3-mini", temperature: 0.4, messages: [{ role: "system", content: systemPrompt }, { role: "user", content: `Learner level: ${level}. Message: ${message}` }] }) });
    if (!result.ok) return { response: fallback(message, level), configured: true };
    const body = await result.json() as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    const cleaned = text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
    const parsed = aiResponseSchema.safeParse(JSON.parse(cleaned));
    return { response: parsed.success ? parsed.data : fallback(message, level), configured: true };
  } catch {
    return { response: fallback(message, level), configured: true };
  }
}
