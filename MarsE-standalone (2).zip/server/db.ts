import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, achievements, conversationMessages, conversations, dailyLessons, exerciseResults, grammarProgress, interviews, profiles, progress as progressTable, storyProgress, users, vocabulary, weeklyReports } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() { if (!_db && process.env.DATABASE_URL) { try { _db = drizzle(process.env.DATABASE_URL); } catch { console.warn("[Database] Failed to connect"); _db = null; } } return _db; }

export async function upsertUser(user: InsertUser): Promise<void> { if (!user.openId) throw new Error("User openId is required for upsert"); const db = await getDb(); if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; } const values: InsertUser = { openId: user.openId }; const updateSet: Record<string, unknown> = {}; (['name', 'email', 'loginMethod'] as const).forEach((field) => { if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; } }); values.lastSignedIn = user.lastSignedIn ?? new Date(); updateSet.lastSignedIn = values.lastSignedIn; if (user.role !== undefined || user.openId === ENV.ownerOpenId) { values.role = user.role ?? "admin"; updateSet.role = values.role; } await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet }); }
export async function getUserByOpenId(openId: string) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return result[0]; }

export type LearningEvent = "conversation" | "vocabulary" | "exercise" | "exerciseCorrect" | "pronunciation" | "interview";
export async function recordLearningEvent(userId: number, event: LearningEvent, amount = 1) {
  const db = await getDb(); if (!db) return { persisted: false };
  const rows = await db.select().from(progressTable).where(eq(progressTable.userId, userId)).limit(1); const current = rows[0];
  const update: Partial<typeof progressTable.$inferInsert> = { xp: (current?.xp ?? 0) + amount * 5 };
  if (event === "conversation") update.conversationCount = (current?.conversationCount ?? 0) + 1;
  if (event === "vocabulary") update.wordsLearned = (current?.wordsLearned ?? 0) + amount;
  if (event === "exercise") update.exerciseAccuracy = current?.exerciseAccuracy ?? 0;
  if (event === "exerciseCorrect") update.exerciseAccuracy = Math.min(100, (current?.exerciseAccuracy ?? 0) + 5);
  if (event === "interview") update.xp = (current?.xp ?? 0) + 35;
  if (current) await db.update(progressTable).set(update).where(eq(progressTable.userId, userId)); else await db.insert(progressTable).values({ userId, xp: update.xp ?? 0, conversationCount: update.conversationCount ?? 0, wordsLearned: update.wordsLearned ?? 0, exerciseAccuracy: update.exerciseAccuracy ?? 0 });
  return { persisted: true };
}

export async function getProgressSnapshot(userId: number) { const db = await getDb(); if (!db) return null; const rows = await db.select().from(progressTable).where(eq(progressTable.userId, userId)).limit(1); return rows[0] ?? null; }

export async function deleteUserData(userId: number) {
  const db = await getDb(); if (!db) return { persisted: false };
  await db.delete(vocabulary).where(eq(vocabulary.userId, userId)); await db.delete(grammarProgress).where(eq(grammarProgress.userId, userId)); await db.delete(exerciseResults).where(eq(exerciseResults.userId, userId)); await db.delete(storyProgress).where(eq(storyProgress.userId, userId)); await db.delete(interviews).where(eq(interviews.userId, userId)); await db.delete(achievements).where(eq(achievements.userId, userId)); await db.delete(dailyLessons).where(eq(dailyLessons.userId, userId)); await db.delete(weeklyReports).where(eq(weeklyReports.userId, userId)); await db.delete(profiles).where(eq(profiles.userId, userId)); await db.delete(progressTable).where(eq(progressTable.userId, userId));
  const userConversations = await db.select({ id: conversations.id }).from(conversations).where(eq(conversations.userId, userId)); for (const row of userConversations) await db.delete(conversationMessages).where(eq(conversationMessages.conversationId, row.id)); await db.delete(conversations).where(eq(conversations.userId, userId));
  return { persisted: true };
}
