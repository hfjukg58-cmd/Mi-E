import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(), openId: varchar("openId", { length: 64 }).notNull().unique(), name: text("name"), email: varchar("email", { length: 320 }), loginMethod: varchar("loginMethod", { length: 64 }), role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(), createdAt: timestamp("createdAt").defaultNow().notNull(), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(), lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const profiles = mysqlTable("profiles", {
  id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), displayName: varchar("displayName", { length: 120 }).notNull(), level: mysqlEnum("level", ["Beginner", "Intermediate", "Advanced"]).default("Beginner").notNull(), goal: varchar("goal", { length: 80 }).default("عام").notNull(), createdAt: timestamp("createdAt").defaultNow().notNull(), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const vocabulary = mysqlTable("vocabulary", {
  id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), word: varchar("word", { length: 120 }).notNull(), meaning: varchar("meaning", { length: 240 }).notNull(), example: text("example"), level: mysqlEnum("level", ["Beginner", "Intermediate", "Advanced"]).default("Beginner").notNull(), mastery: int("mastery").default(0).notNull(), createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const grammarProgress = mysqlTable("grammarProgress", { id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), lessonId: varchar("lessonId", { length: 80 }).notNull(), progress: int("progress").default(0).notNull(), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull() });
export const exerciseResults = mysqlTable("exerciseResults", { id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), exerciseId: varchar("exerciseId", { length: 80 }).notNull(), correct: int("correct").default(0).notNull(), answer: text("answer"), createdAt: timestamp("createdAt").defaultNow().notNull() });
export const conversations = mysqlTable("conversations", { id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), level: mysqlEnum("level", ["Beginner", "Intermediate", "Advanced"]).default("Beginner").notNull(), createdAt: timestamp("createdAt").defaultNow().notNull() });
export const conversationMessages = mysqlTable("conversationMessages", { id: int("id").autoincrement().primaryKey(), conversationId: int("conversationId").notNull(), role: mysqlEnum("role", ["user", "assistant"]).notNull(), content: text("content").notNull(), correctionJson: text("correctionJson"), createdAt: timestamp("createdAt").defaultNow().notNull() });
export const stories = mysqlTable("stories", { id: int("id").autoincrement().primaryKey(), slug: varchar("slug", { length: 80 }).notNull().unique(), title: varchar("title", { length: 180 }).notNull(), level: mysqlEnum("level", ["Beginner", "Intermediate", "Advanced"]).notNull(), body: text("body").notNull(), translation: text("translation") });
export const storyProgress = mysqlTable("storyProgress", { id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), storyId: int("storyId").notNull(), score: int("score").default(0).notNull(), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull() });
export const interviews = mysqlTable("interviews", { id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), job: varchar("job", { length: 160 }).notNull(), level: mysqlEnum("level", ["Beginner", "Intermediate", "Advanced"]).default("Intermediate").notNull(), status: mysqlEnum("status", ["active", "completed"]).default("active").notNull(), reportJson: text("reportJson"), createdAt: timestamp("createdAt").defaultNow().notNull() });
export const achievements = mysqlTable("achievements", { id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), key: varchar("key", { length: 80 }).notNull(), unlockedAt: timestamp("unlockedAt").defaultNow().notNull() });
export const progress = mysqlTable("progress", { id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), xp: int("xp").default(0).notNull(), streak: int("streak").default(0).notNull(), wordsLearned: int("wordsLearned").default(0).notNull(), conversationCount: int("conversationCount").default(0).notNull(), exerciseAccuracy: int("exerciseAccuracy").default(0).notNull(), updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull() });
export const dailyLessons = mysqlTable("dailyLessons", { id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), lessonDate: varchar("lessonDate", { length: 10 }).notNull(), stepsJson: text("stepsJson").notNull(), completed: int("completed").default(0).notNull() });
export const weeklyReports = mysqlTable("weeklyReports", { id: int("id").autoincrement().primaryKey(), userId: int("userId").notNull(), weekStart: varchar("weekStart", { length: 10 }).notNull(), reportJson: text("reportJson").notNull(), createdAt: timestamp("createdAt").defaultNow().notNull() });

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
