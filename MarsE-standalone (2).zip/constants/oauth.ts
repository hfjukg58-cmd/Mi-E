import * as Linking from "expo-linking";
import Constants from "expo-constants";
import * as ReactNative from "react-native";

const extra = (Constants.expoConfig?.extra ?? {}) as Record<string, string | undefined>;
const apiBase = extra.apiBaseUrl ?? process.env.EXPO_PUBLIC_API_BASE_URL ?? "";
const portal = extra.oauthPortalUrl ?? process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL ?? "";
const appId = extra.appId ?? process.env.EXPO_PUBLIC_APP_ID ?? "com.marse.app";

export const OAUTH_PORTAL_URL = portal;
export const OAUTH_SERVER_URL = extra.oauthServerUrl ?? process.env.EXPO_PUBLIC_OAUTH_SERVER_URL ?? "";
export const APP_ID = appId;
export const OWNER_OPEN_ID = process.env.EXPO_PUBLIC_OWNER_OPEN_ID ?? "";
export const OWNER_NAME = process.env.EXPO_PUBLIC_OWNER_NAME ?? "";
export const API_BASE_URL = apiBase;
export const SESSION_TOKEN_KEY = "mars_e_session_token";
export const USER_INFO_KEY = "mars_e_user_info";

export function getApiBaseUrl(): string {
  if (API_BASE_URL) return API_BASE_URL.replace(/\/$/, "");
  if (ReactNative.Platform.OS === "web" && typeof window !== "undefined") {
    const { protocol, hostname, port } = window.location;
    if (port === "8081") return `${protocol}//${hostname.replace(/^8081-/, "3000-")}`;
    return `${protocol}//${hostname}`;
  }
  return "";
}

export const getRedirectUri = () => ReactNative.Platform.OS === "web" ? `${getApiBaseUrl()}/api/oauth/callback` : Linking.createURL("/oauth/callback", { scheme: "marse" });

export const getLoginUrl = () => {
  if (!OAUTH_PORTAL_URL) throw new Error("OAuth is not configured. Use local learning mode or set EXPO_PUBLIC_OAUTH_PORTAL_URL.");
  const url = new URL(`${OAUTH_PORTAL_URL.replace(/\/$/, "")}/authorize`);
  url.searchParams.set("client_id", APP_ID); url.searchParams.set("redirect_uri", getRedirectUri());
  return url.toString();
};

export async function startOAuthLogin(): Promise<string | null> {
  const loginUrl = getLoginUrl();
  if (ReactNative.Platform.OS === "web") { window.location.href = loginUrl; return null; }
  if (await Linking.canOpenURL(loginUrl)) await Linking.openURL(loginUrl);
  return null;
}
