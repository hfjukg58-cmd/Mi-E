import type { Metrics } from "react-native-safe-area-context";

type Callback = (metrics: Metrics) => void;
export function initStandaloneRuntime() {}
export function subscribeSafeAreaInsets(_callback: Callback): () => void { return () => undefined; }
