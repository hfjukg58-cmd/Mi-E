import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import * as Auth from "@/lib/_core/auth";

export type Level = "Beginner" | "Intermediate" | "Advanced";
export type Goal = "الدراسة" | "العمل" | "السفر" | "المحادثة" | "مقابلات العمل" | "عام";
export type MarsState = "idle" | "welcome" | "listening" | "thinking" | "speaking" | "correct" | "correction" | "happy" | "error" | "encouraging";

type Profile = { name: string; level: Level; goal: Goal } | null;
type Settings = { sound: boolean; notifications: boolean; voiceSpeed: number };
type Progress = { xp: number; streak: number; words: number; conversations: number; exercises: number; correctExercises: number; pronunciation: number; interviewSessions: number; grammar: number; completedLessons: string[]; lastActivity?: string };
type VocabularyWord = { id: string; word: string; meaning: string; example: string; level: Level; mastery: number; addedAt: string };

type MarsContextValue = {
  hydrated: boolean;
  profile: Profile;
  progress: Progress;
  settings: Settings;
  vocabulary: VocabularyWord[];
  marsState: MarsState;
  setMarsState: (state: MarsState) => void;
  saveProfile: (profile: NonNullable<Profile>) => void;
  addXp: (amount: number) => void;
  completeLesson: (lessonId: string, amount?: number) => void;
  recordExercise: (correct: boolean) => void;
  recordConversation: () => void;
  recordInterview: () => void;
  recordPronunciation: (score: number) => void;
  addVocabulary: (word: Omit<VocabularyWord, "id" | "addedAt">) => void;
  setSettings: (patch: Partial<Settings>) => void;
  clearData: () => Promise<void>;
};

const STORAGE_KEY = "mars-e-state-v1";
const initialProgress: Progress = { xp: 240, streak: 3, words: 24, conversations: 2, exercises: 8, correctExercises: 6, pronunciation: 1, interviewSessions: 0, grammar: 34, completedLessons: [], lastActivity: "" };
const emptyProgress: Progress = { xp: 0, streak: 0, words: 0, conversations: 0, exercises: 0, correctExercises: 0, pronunciation: 0, interviewSessions: 0, grammar: 0, completedLessons: [], lastActivity: "" };
const initialSettings: Settings = { sound: true, notifications: true, voiceSpeed: 1 };

const MarsContext = createContext<MarsContextValue | null>(null);

function markActivity(current: Progress, xp: number) {
  const today = new Date().toISOString().slice(0, 10);
  return { ...current, xp: current.xp + xp, streak: current.lastActivity === today ? current.streak : current.streak + 1, lastActivity: today };
}

export function MarsProvider({ children }: { children: React.ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [profile, setProfile] = useState<Profile>(null);
  const [progress, setProgress] = useState<Progress>(initialProgress);
  const [settings, setSettingsState] = useState<Settings>(initialSettings);
  const [vocabulary, setVocabulary] = useState<VocabularyWord[]>([
    { id: "opportunity", word: "opportunity", meaning: "فرصة", example: "This is a great opportunity.", level: "Beginner", mastery: 48, addedAt: "2026-09-29" },
    { id: "improve", word: "improve", meaning: "يطوّر / يحسّن", example: "I want to improve my English.", level: "Beginner", mastery: 72, addedAt: "2026-09-28" },
    { id: "confident", word: "confident", meaning: "واثق", example: "She feels confident speaking English.", level: "Intermediate", mastery: 22, addedAt: "2026-09-27" },
  ]);
  const [marsState, setMarsState] = useState<MarsState>("idle");

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (raw) {
        try {
          const parsed = JSON.parse(raw);
          setProfile(parsed.profile ?? null);
          setProgress({ ...initialProgress, ...(parsed.progress ?? {}) });
          setSettingsState({ ...initialSettings, ...(parsed.settings ?? {}) });
          setVocabulary(parsed.vocabulary ?? vocabulary);
        } catch {
          // Keep safe defaults when local storage is corrupted.
        }
      }
      setHydrated(true);
    }).catch(() => setHydrated(true));
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ profile, progress, settings, vocabulary })).catch(() => undefined);
  }, [hydrated, profile, progress, settings, vocabulary]);

  const value = useMemo<MarsContextValue>(() => ({
    hydrated,
    profile,
    progress,
    settings,
    vocabulary,
    marsState,
    setMarsState,
    saveProfile: (nextProfile) => setProfile(nextProfile),
    addXp: (amount) => setProgress((current) => markActivity(current, amount)),
    completeLesson: (lessonId, amount = 20) => setProgress((current) => current.completedLessons.includes(lessonId) ? current : markActivity({ ...current, completedLessons: [...current.completedLessons, lessonId] }, amount)),
    recordExercise: (correct) => setProgress((current) => markActivity({ ...current, exercises: current.exercises + 1, correctExercises: current.correctExercises + (correct ? 1 : 0) }, correct ? 15 : 5)),
    recordConversation: () => setProgress((current) => markActivity({ ...current, conversations: current.conversations + 1 }, 25)),
    recordInterview: () => setProgress((current) => markActivity({ ...current, interviewSessions: current.interviewSessions + 1 }, 35)),
    recordPronunciation: (score) => setProgress((current) => markActivity({ ...current, pronunciation: current.pronunciation + 1 }, Math.round(score / 4))),
    addVocabulary: (word) => { if (vocabulary.some((item) => item.word.toLowerCase() === word.word.toLowerCase())) return; setVocabulary((current) => [{ ...word, id: `${word.word}-${Date.now()}`, addedAt: new Date().toISOString().slice(0, 10) }, ...current]); setProgress((current) => markActivity({ ...current, words: current.words + 1 }, 8)); },
    setSettings: (patch) => setSettingsState((current) => ({ ...current, ...patch })),
    clearData: async () => { await AsyncStorage.removeItem(STORAGE_KEY); await Promise.all([Auth.removeSessionToken(), Auth.clearUserInfo()]); setProfile(null); setProgress(emptyProgress); setSettingsState(initialSettings); setVocabulary([]); setMarsState("idle"); },
  }), [hydrated, profile, progress, settings, vocabulary, marsState]);

  return <MarsContext.Provider value={value}>{children}</MarsContext.Provider>;
}

export function useMars() {
  const value = useContext(MarsContext);
  if (!value) throw new Error("useMars must be used inside MarsProvider");
  return value;
}
